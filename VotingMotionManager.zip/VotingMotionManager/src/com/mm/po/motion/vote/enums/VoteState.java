package com.mm.po.motion.vote.enums;

/**
 * 
 * @author Arun Devadoss
 *
 */
public enum VoteState {

	Y, N
}
