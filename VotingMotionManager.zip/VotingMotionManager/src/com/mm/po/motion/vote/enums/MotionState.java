package com.mm.po.motion.vote.enums;

/**
 * 
 * @author Arun Devadoss
 *
 */
public enum MotionState {

	PASSED, FAILED, TIED
}
