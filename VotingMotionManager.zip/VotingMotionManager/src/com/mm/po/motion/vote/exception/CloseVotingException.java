package com.mm.po.motion.vote.exception;

/**
 * 
 * @author Arun devadoss
 *
 */
public class CloseVotingException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */

	public CloseVotingException(String message) {

		super(message);
	}

}
