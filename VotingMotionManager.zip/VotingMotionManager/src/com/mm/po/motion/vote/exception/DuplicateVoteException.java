package com.mm.po.motion.vote.exception;

/**
 * 
 * @author Arun Devadoss
 *
 */
public class DuplicateVoteException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */

	public DuplicateVoteException(String message) {

		super(message);
	}

}
