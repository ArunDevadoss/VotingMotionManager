package com.mm.po.motion.vote.enums;

/**
 * 
 * @author Arun Devadoos
 *
 */
public enum MotionStatus {

	CLOSED, OPENED

}
