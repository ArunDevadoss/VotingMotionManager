package com.mm.po.motion.vote.exception;

/**
 * 
 * @author Arun Devadoss
 *
 */
public class MotionException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */

	public MotionException(String message) {

		super(message);
	}

}
